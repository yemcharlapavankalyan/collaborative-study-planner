/**
 * 
 */
/**
 * 
 */
module CollaborativeStudyPlanner {
}